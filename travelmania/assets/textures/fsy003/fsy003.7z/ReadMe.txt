
	

	GUI - Game Buttons fsy003
	------------------------------------------------------------
	Created by : Feti Sumaryanti (http://fsy.itch.io)

                   
	Hi, thanks for downloading this Game Asset.
	------------------------------------------------------------

	About License :

	You can use this Asset in unlimited number of commercial and
	non-commercial project, but resell and reupload this assets 
        (the file of the assets) everywhere or on every other media 
        are prohibited.

	------------------------------------------------------------
	Follow me for updates
	http://fsy.itch.io
	

	
